export class DoctorDashboardModel{
    id:number=0;
    firstName:string="";
    lastName:string="";
    email:string="";
    phone:string="";
    salary:string="";

}